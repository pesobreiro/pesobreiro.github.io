/*
 * Copyright (c) 2002 World Wide Web Consortium,
 * (Massachusetts Institute of Technology, Institut National de
 * Recherche en Informatique et en Automatique, Keio University). All
 * Rights Reserved. This program is distributed under the W3C's Software
 * Intellectual Property License. This program is distributed in the
 * hope that it will be useful, but WITHOUT ANY WARRANTY; without even
 * the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE.
 * See W3C License http://www.w3.org/Consortium/Legal/ for more details.
 */

package org.w3c.dom.html2;

import org.w3c.dom.DOMImplementation;

/**
 *  The <code>HTMLDOMImplementation</code> interface extends the 
 * <code>DOMImplementation</code> interface with a method for creating an 
 * HTML document instance. The core <code>DOMImplementation</code> interface 
 * can be used to create XHTML documents by passing the XHTML namespace as 
 * the namespace for the root element. 
 * <p>See also the <a href='http://www.w3.org/TR/2002/CR-DOM-Level-2-HTML-20020605'>Document Object Model (DOM) Level 2 HTML Specification</a>.
 * @since DOM Level 2
 */
public interface HTMLDOMImplementation extends DOMImplementation {
    /**
     * Creates an <code>HTMLDocument</code> object with the minimal tree made 
     * of the following elements: <code>HTML</code>, <code>HEAD</code>, 
     * <code>TITLE</code>, and <code>BODY</code>.
     * @param title The title of the document to be set as the content of the 
     *   <code>TITLE</code> element, through a child <code>Text</code> node.
     * @return A new <code>HTMLDocument</code> object.
     */
    public HTMLDocument createHTMLDocument(String title);

}
